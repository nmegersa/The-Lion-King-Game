#include "Board.cpp"
#include "Player.cpp"


//REMEBER TO USE WHILE LOOPS FOR ERROR HANDLING
//WHEN ASKING FOR USER INPUT/CHOICE
int main(){
    //intialize variables to store user input/choice
    Board board(2);
    board.initializeBoard();



    //display characters from characters file 
    //display their names and their stats


    //prompt user(s) to enter their names


    //asks user what character they would like to choose

    //prompt user to select 1 for cub training path or 2 for pridelands

    //intialize and assign variables values for first character
    //create a player object using these variables as parameters for the first player
    Player playerOne("Simba", 500, 1000, 500, false, 5);
    Player playerTwo("Mufasa", 200, 200, 200, true, 7);

    //assign the previous variables values for the second character chosen
    //create another player object for 2nd player, using these variables as parameters
    board.displayBoard();
    cout << playerOne.getName() << " strength: " << playerOne.getStrength() << endl;
    cout << playerTwo.getName() << " strength: " << playerTwo.getStrength() << endl;

    //first round starts with player one turn and displaying the board
    //before each turn display menu where user can check stats, etc.
    //use srand() in the range of 1-6 included for the spinner
    //use movePlayer() in a loop iterting the number of times that the spinner produced
    
    
    
    
    
    
    
    //if player lands on a special tile, random, challenge, etc
    //ask for user input if it's riddle
    //otherwise print out the result of the special tile
    
    
    
    
    
    
    //check if player has advisor that negates any negatives
    //adjust stats as needed
    
    
    
    
    
    
    //redisplay menu before each turn and respin when user ready
    //repeat this process until both players reach pride rock
    
    
    
    
    
    
    //whoever has most amount of pridepoints wins
    //print out winner and number of pride points
    //print out stats of both lions
    //print out all these game details to another file


    //give option to play again or exit the game
    









}

