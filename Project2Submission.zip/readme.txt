To compile this program:
Open a new terminal and type this in:
g++ -Wall -Werror -Wpedantic -std=c++17 GameDriver.cpp
Proceed to type in after program has been compiled:
./a.out
