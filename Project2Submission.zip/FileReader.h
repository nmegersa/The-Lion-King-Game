#include "FileReader.cpp"


class FileReader{
    private:
    string name;
    int age;
    int strength;
    int stamina;
    int wisdom;

    public:
        void displayCharacters();
        void sortCharacter(string choice);
        




    

};

