#ifndef TILE_H
#define TILE_H

struct Tile{
    char color;
};

#endif