#include <fstream>
#include <ostream>
#include <sstream>
using namespace std;